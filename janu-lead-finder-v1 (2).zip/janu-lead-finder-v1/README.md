# Janu Lead Finder V1

Functional V1 prototype for the agreed lead-generation SaaS flow.

## Frontend
Open `frontend/index.html` directly, or deploy the `frontend` folder to Vercel Drop.

## Backend
```bash
cd backend
python -m venv .venv
# activate the venv
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

## V1 behavior
- 500 free credits
- Keyword + Location + Radius + Lead limit
- Search UX
- 9-column lead result table
- Verified/Pending status display
- CSV export
- API skeleton for search and credits

Provider integrations (Google Search/Apollo/Prospeo/ZoomInfo), PostgreSQL, Redis/Celery, authentication, billing and Google Sheets sync require production credentials and deployment infrastructure; no credentials are embedded in this prototype.
