from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title='Janu Lead Finder API', version='1.0.0')

class SearchRequest(BaseModel):
    keyword: str
    location: str
    radius_miles: int = 25
    lead_limit: int = 50

@app.get('/health')
def health():
    return {'status': 'ok', 'service': 'janu-lead-finder-api'}

@app.post('/api/v1/searches')
def create_search(req: SearchRequest):
    return {'search_id': 'demo-search-001', 'status': 'queued', 'request': req.model_dump()}

@app.get('/api/v1/credits')
def credits():
    return {'credits': 500}
